import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import EmailValidatingForm from "../src/EmailValidatingForm";

function emailvalidating() {
  return <EmailValidatingForm />;
}

export default emailvalidating;
