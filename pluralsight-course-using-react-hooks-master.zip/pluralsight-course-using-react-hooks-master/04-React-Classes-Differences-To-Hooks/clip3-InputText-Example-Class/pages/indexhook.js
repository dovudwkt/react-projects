import InputElementHook from "../src/InputElementHook";

const indexHook = () => {
  return <InputElementHook />;
};

export default indexHook;
