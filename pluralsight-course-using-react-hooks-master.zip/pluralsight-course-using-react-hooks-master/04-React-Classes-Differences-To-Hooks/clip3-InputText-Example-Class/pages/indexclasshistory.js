import InputElementClassHistory from "../src/InputElementClassHistory";

const indexclasshistory = () => {
  return <InputElementClassHistory />;
};

export default indexclasshistory;
