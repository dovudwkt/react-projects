import InputElementClass from "../src/InputElementClass";

const indexclass = () => {
  return <InputElementClass />;
};

export default indexclass;
