import InputElementHookHistory from "../src/InputElementHookHistory";

const indexHookHistory = () => {
  return <InputElementHookHistory />;
};

export default indexHookHistory;
