import React from "react";
import App from "../src/App";

function login() {
  return <App pageName="Login" />;
}

export default login;