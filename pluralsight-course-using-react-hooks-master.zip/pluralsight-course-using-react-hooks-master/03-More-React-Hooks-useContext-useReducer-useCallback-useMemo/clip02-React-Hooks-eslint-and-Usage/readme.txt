See next directory, ../clip04-Updating-Example-To-Full-Conf-Site for .eslint file in React project
