import React from "react";
import App from "../src/App";

function index() {
  return <App pageName="Home" />;
}

export default index;
