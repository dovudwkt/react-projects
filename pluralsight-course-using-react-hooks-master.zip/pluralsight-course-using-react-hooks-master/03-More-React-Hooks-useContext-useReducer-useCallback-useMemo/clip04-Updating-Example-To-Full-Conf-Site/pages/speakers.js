import React from "react";
import App from "../src/App";

function speakers() {
  return <App pageName="Speakers" />;
}

export default speakers;
